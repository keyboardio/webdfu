Chrysalis Firmware Bundle 0.92.0+77

## Build Information

| Architecture | Core                                                                               |
|:-------------|:-----------------------------------------------------------------------------------|
| AVR          | keyboardio/Kaleidoscope-Bundle-Keyboardio@67c408a38df81817e542ab38385ba654ef498467 |
| GD32         | keyboardio/ArduinoCore-GD32-Keyboardio@b141855b7906cd393dd60eedcba5b084164e9655    |

### Libraries

| Library                   | Link                                                                          |
|:--------------------------|:------------------------------------------------------------------------------|
| KeyboardioHID (avr)       | keyboardio/KeyboardioHID@1caab9b6fd6d28f96d00d733f5c62eaef3c9c217             |
| KeyboardioHID (gd32)      | keyboardio/KeyboardioHID@1caab9b6fd6d28f96d00d733f5c62eaef3c9c217             |
| Kaleidoscope              | keyboardio/Kaleidoscope@f936f0984c24c87a9e5b324e29570e83c09b5738              |
| Chrysalis-Firmware-Bundle | keyboardio/Chrysalis-Firmware-Bundle@bf9d5b721c3b7085a959d8b6852f6541b092cb7e |

# Changelog

No changes yet.
